<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InventoryForecastingController extends Controller
{
    //
    function CreateInventoryForecasting()
    {
    	session()->put("titlename","Inventory Forecasting - Inventory Planning Admin Panel - Premier Group Of Companies");
    $branchid=session('branchid');
    $branchid2=session('branchid');
    $branchid=explode(',', $branchid);
   
    $formulamasterdata=DB::SELECT("SELECT * FROM `ipl_formula_master`");
    $branchdata=DB::SELECT("SELECT * FROM `ipl_branch_master` where branch_code in ($branchid2) order by branch_code asc");

    $companydata=DB::SELECT("SELECT * FROM `ipl_company_master` order by company_title asc");

    $questiondata=DB::SELECT("SELECT question_title,question_id FROM `ipl_checklist_question` where status=1");


    return view('create_inventory_forecasting',['formulamasterdata'=>$formulamasterdata,'data'=>'','branchdata'=>$branchdata,'companydata'=>$companydata,'questiondata'=>$questiondata,'direct'=>0]);
    }

     function CreateInventoryForecastingthrough($formulaid,$formuladetailid,$branchid,$companyid,$shelflife)
    {
      session()->put("titlename","Inventory Forecasting - Inventory Planning Admin Panel - Premier Group Of Companies");
    $branchid2=session('branchid');
  
   
    $formulamasterdata=DB::SELECT("SELECT * FROM `ipl_formula_master`");
    $branchdata=DB::SELECT("SELECT * FROM `ipl_branch_master` where branch_code in ($branchid2) order by branch_code asc");

    $companydata=DB::SELECT("SELECT * FROM `ipl_company_master` order by company_title asc");

    $questiondata=DB::SELECT("SELECT question_title,question_id FROM `ipl_checklist_question` where status=1");


    return view('create_inventory_forecasting',['formulamasterdata'=>$formulamasterdata,'data'=>'','branchdata'=>$branchdata,'companydata'=>$companydata,'questiondata'=>$questiondata,'direct'=>1,'formulaid'=>$formulaid,'formuladetailid'=>$formuladetailid,'branchid'=>$branchid,'companyid'=>$companyid,'shelflife'=>$shelflife]);
    }
 

    function GetFormulaGroup(Request $req)
    {

         $formula_id=$req->formula_id;
        
         $user=DB::select("SELECT * FROM `ipl_group_master` where formula_id='$formula_id'");
         
        return response()->json($user);

        
    }

    function CheckFirstVersionOrNot(Request $req)
    {

         $company_id=$req->company_id;
         $branch_id=$req->branch_id;
         $forecasting_month=$req->forecasting_month;

        
         $user=DB::select("SELECT ifnull(count(forecasting_id),0) as totalforecasting FROM `tbl_forecasting_master` where company_id='$company_id' AND branch_id='$branch_id' AND forecasting_month='$forecasting_month'");
         foreach($user as $us)
         {
          $totalforecasting=$us->totalforecasting;
         }
         
        return response()->json($totalforecasting);

        
    }

    

    function GetGroupCompany(Request $req)
    {

         $group_id=$req->group_id;
         if($group_id !="")
         {
          $user=DB::select("select comp.company_code,comp.company_title from ipl_group_master grp inner join ipl_company_master comp on grp.company_id=comp.company_code where grp.group_id='$group_id'");
         }
         else{
          $user=DB::select("SELECT company_code,company_title FROM `ipl_company_master` order by company_title asc");
         }
         
         
        return response()->json($user);

        
    }
    

    function CreateInventoryForecasting2(Request $req)
    {
    session()->put("titlename","Inventory Forecasting - Inventory Planning Admin Panel - Premier Group Of Companies");
    $branchid=session('branchid');
    $branchid2=session('branchid');
    $branchid=explode(',', $branchid);

    $formula_id=$req->formula_id;
    $formula_det_id=$req->formula_det_id;
    $group_id=$req->group_id;
    $company_id=$req->company_id;
    $branch_id=$req->branch_id;
    $shelf_life=$req->shelf_life;
    $forecasting_month=$req->forecasting_month;
    $stockshowing=$req->stockshowing;
    $versionprevious=$req->versionprevious;



    $formulamasterdata=DB::SELECT("SELECT * FROM `ipl_formula_master`");
    $branchdata=DB::SELECT("SELECT * FROM `ipl_branch_master` order by branch_code asc");

    $companydata=DB::SELECT("SELECT * FROM `ipl_company_master` order by company_title asc");

    $multiplydata=DB::SELECT("SELECT multiply_by,detail_id FROM `ipl_formula_detail` where formula_id='$formula_id'");

    $groupdata=DB::SELECT("select group_id,group_name from ipl_group_master where formula_id='$formula_id'");

    if($group_id !="")
    {
      $productdata=DB::SELECT("SELECT prod.product_code,prod.product_name FROM `ipl_group_mapping` grp inner join ipl_products prod on grp.product_code=prod.product_code where grp.group_id='$group_id' order by prod.product_name asc");
    }
    else{
      $productdata=DB::SELECT("SELECT product_code,product_name FROM `ipl_products` where company_code='$company_id' AND status=1 order by product_name asc");
    }

    $totalgroupproductcount=0;
    $totalgroupproduct=DB::SELECT("SELECT ifnull(count(mapping_id),0) as totalgroupproduct FROM `ipl_group_mapping` where product_code in (select product_code from ipl_products where company_code='$company_id' and status=1)");
    foreach($totalgroupproduct as $grp)
    {
      $totalgroupproductcount=$grp->totalgroupproduct;
    }

    $totalcompanyproductcount=0;
    $totalcompanyproduct=DB::SELECT("select ifnull(count(product_id),0) as totalcompanyproduct from ipl_products where company_code='$company_id' and status=1");
    foreach($totalcompanyproduct as $prd)
    {
      $totalcompanyproductcount=$prd->totalcompanyproduct;
    }

    $modalshowstatus='No';
    if($totalgroupproductcount != $totalcompanyproductcount)
    {
      $modalshowstatus="Yes";
    }


    $notsetpackingproduct=0;
    $notsetpacking=DB::SELECT("select ifnull(count(product_id),0) as totalnotsetpackingsize from ipl_products where company_code='$company_id' and status=1 AND packing_size=0");
    foreach($notsetpacking as $setpacking)
    {
     $notsetpackingproduct=$setpacking->totalnotsetpackingsize;
    }







    return view('create_inventory_forecasting2',['formulamasterdata'=>$formulamasterdata,'data'=>'','branchdata'=>$branchdata,'companydata'=>$companydata,'formula_id'=>$formula_id,'formula_det_id'=>$formula_det_id,'group_id'=>$group_id,'company_id'=>$company_id,'branch_id'=>$branch_id,'shelf_life'=>$shelf_life,'productdata'=>$productdata,'groupdata'=>$groupdata,'multiplydata'=>$multiplydata,'modalshowstatus'=>$modalshowstatus,'notsetpackingproduct'=>$notsetpackingproduct,'forecasting_month'=>$forecasting_month,'stockshowing'=>$stockshowing,'versionprevious'=>$versionprevious]);
    }


    function GetCompanyProduct(Request $req)
    {

         $new_company_id=$req->new_company_id;
         
         $user=DB::SELECT("SELECT * FROM `ipl_products` where company_code='$new_company_id'");
         
         
        return response()->json($user);

        
    }

    function GetFormulaMultiply(Request $req)
    {

         $formula_id=$req->formula_id;
         
         $user=DB::SELECT("SELECT multiply_by FROM `ipl_formula_detail` where formula_id='$formula_id'");
         
         
        return response()->json($user);

        
    }

    function GetMultiplyGroupId(Request $req)
    {

         $new_multiply_by=$req->new_multiply_by;
         $formula_id=$req->formula_id;
         $group_id=0;
         $user=DB::SELECT("SELECT detail_id as group_id FROM `ipl_formula_detail` where formula_id='$formula_id' AND multiply_by='$new_multiply_by'");
         foreach($user as $us)
         {
          $group_id=$us->group_id;
         }
        return response()->json($group_id);
    }
    

    function GetProductInventoryCosting(Request $req)
    {

         $new_product_id=$req->new_product_id;
         $branch_id=$req->branch_id;

         $productname="";
         $productdata=DB::SELECT("SELECT * FROM `ipl_products` where product_code='$new_product_id'");
         foreach($productdata as $prd)
         {
          $productname=$prd->product_name;
         }

         $sales_qty1=0;$month_year1="";$sales_qty2=0;$month_year2="";$sales_qty3=0;$month_year3="";$in_stock=0;$in_stock_monthyear="";$in_transitstock=0;

         $invdata=DB::SELECT("SELECT sales_qty1,month_year1,sales_qty2,month_year2,sales_qty3,month_year3,in_stock,in_stock_monthyear,in_transitstock FROM `ipl_branchwise_product_stock` where branch_code=$branch_id AND product_code=$new_product_id");
         foreach($invdata as $inv)
         {
          $sales_qty1=$inv->sales_qty1;
          $sales_qty2=$inv->sales_qty2;
          $sales_qty3=$inv->sales_qty3;
          $in_stock=$inv->in_stock;
          $in_transitstock=$inv->in_transitstock;


         }

         
         $responseData = [
        'product_name' => $productname,
        'sales_qty1' => $sales_qty1,
        'sales_qty2' => $sales_qty2,
        'sales_qty3' => $sales_qty3,
        'in_stock' => $in_stock,
        'in_transitstock' => $in_transitstock,
       ];
         
        return response()->json($responseData);
        
    }


    function SaveForecasting(Request $req)
    {
    
    session()->put("titlename","Inventory Forecasting - Inventory Planning Admin Panel - Premier Group Of Companies");
    $branchid=session('branchid');
    $branchid2=session('branchid');
    $branchid=explode(',', $branchid);

    $formula_id=$req->formula_id;
    $formula_det_id=$req->formula_det_id;
    $group_id=$req->group_id;
    $company_id=$req->company_id;
    $branch_id=$req->branch_id;
    $shelf_life=$req->shelf_life;
    $multiply_by=$req->multiply_by;
    $formulaname=$req->formulaname;
    $forecasting_month=$req->forecasting_month;
    $indexcount=$req->indexcount;
    $stockshowing=$req->stockshowing;
    $versionprevious=$req->versionprevious;

    if($versionprevious == 0)
    {
    $formno=0;
    $data_formno=DB::SELECT("SELECT COALESCE(MAX(forcasting_formno), 0) + 1 AS newforcasting FROM tbl_forecasting_master");
    foreach($data_formno as $fmno)
    {
      $formno=$fmno->newforcasting;
    }

    $unique_key="FCST_".date('Ym')."0".$formno;
    }
    else{

      $fg_gettingkey=DB::SELECT("SELECT forcasting_unique_key,forcasting_formno FROM `tbl_forecasting_master` where company_id='$company_id' AND branch_id='$branch_id' AND forecasting_month='$forecasting_month'");
      foreach($fg_gettingkey as $fkey)
      {
        $unique_key=$fkey->forcasting_unique_key;
        $formno=$fkey->forcasting_formno;
      }

    }
    
    $version_no=$versionprevious + 1;
    $myuserid=session("adminname");
    date_default_timezone_set("Asia/Karachi");
    $currentdate=date('Y-m-d h:i:s');



    DB::table('tbl_forecasting_master')
          ->insert([
            'forcasting_unique_key' => $unique_key,
            'forcasting_formno' => $formno,
            'version_no'=>$version_no,
            'formula_id'=>$formula_id,
            'formula_detail_id'=>$formula_det_id,
            'group_id'=>$group_id,
            'company_id'=>$company_id,
            'branch_id'=>$branch_id,
            'shelf_life'=>$shelf_life,
            'multiply_by'=>$multiply_by,
            'post_user'=>$myuserid,
            'post_datetime'=>$currentdate,
            'forecasting_month'=>$forecasting_month
          ]);

   $forecasting_id=0;
    $dbdataforcast=DB::SELECT("SELECT forecasting_id FROM `tbl_forecasting_master` order by forecasting_id desc limit 1");
    foreach($dbdataforcast as $fcr)
    {
     $forecasting_id=$fcr->forecasting_id;
    }

    for($i=1;$i <= $indexcount;$i++)
    {
      $productcode=$req->input('productcode'.$i);
      $saleqty1_=$req->input('saleqty1_'.$i);
      $saleqty2_=$req->input('saleqty2_'.$i);
      $saleqty3_=$req->input('saleqty3_'.$i);
      $salemonth_1_=$req->input('salemonth_1_'.$i);
      $salemonth_2_=$req->input('salemonth_2_'.$i);
      $salemonth_3_=$req->input('salemonth_3_'.$i);
      $avgsales=$req->input('avgsales'.$i);
      $maxsales=$req->input('maxsales'.$i);
      $instock=$req->input('instock'.$i);
      $in_transitstock=$req->input('in_transitstock'.$i);
      $netstock=$req->input('netstock'.$i);
      $formulaoutput=$req->input('formulaoutput'.$i);
      $demand=$req->input('demand'.$i);
      $finaloutput=$req->input('finaloutput'.$i);
      $rowformulaid=$req->input('rowformulaid'.$i);
      $new_multiply_by=$req->input('new_multiply_by'.$i);
      $instockmonth=$req->input('instockmonth'.$i);
      $groupid=$req->input('groupid'.$i);
      $manualstock=$req->input('manualstock'.$i);

      DB::table('ipl_forecasting_detail')
          ->insert([
            'forecasting_id' => $forecasting_id,
            'product_code' => $productcode,
            'sale_qty1'=>$saleqty1_,
            'sale_qty2'=>$saleqty2_,
            'sale_qty3'=>$saleqty3_,
            'sale_month1'=>$salemonth_1_,
            'sale_month2'=>$salemonth_2_,
            'sale_month3'=>$salemonth_3_,
            'avg_sales'=>$avgsales,
            'max_sales'=>$maxsales,
            'current_stock'=>$instock,
            'current_stockmonth'=>$instockmonth,
            'in_transit_stock'=>$in_transitstock,
            'net_stock'=>$netstock,
            'pr_diff'=>$formulaoutput,
            'demand'=>$demand,
            'pspl_diff'=>$finaloutput,
            'formula_id'=>$rowformulaid,
            'formula_detail_id'=>$formula_det_id,
            'multiply_by'=>$new_multiply_by,
            'group_detail_id'=>$groupid,
            'manual_stock'=>$manualstock
          ]);

      

    }
 
   
    return view('create_inventory_forecasting3',['forecasting_id'=>$forecasting_id,'unique_key'=>$unique_key,'version_no'=>$version_no,'branch_id'=>$branch_id,'company_id'=>$company_id]);
    }


     function ForecastingList()
    {
        
    session()->put("titlename","Forecasting List - Inventory Planning Admin Panel - Premier Group Of Companies");

    $branchid=session('branchid');
    $branchid2=session('branchid');
    $branchid=explode(',', $branchid);

    
    $forecastinglist=DB::SELECT("SELECT * FROM `tbl_forecasting_master` where branch_id in ($branchid2) group by forcasting_unique_key order by forecasting_id desc");


    $branchdata=DB::SELECT("SELECT * FROM `ipl_branch_master` where branch_code in ($branchid2)");

    $companydata=DB::SELECT("SELECT * FROM `ipl_company_master` order by company_title asc");
   

    return view('forecasting_list',['forecastinglist'=>$forecastinglist,'branchdata'=>$branchdata,'companydata'=>$companydata,'branchid2'=>$branchid2]);
    }


    function SearchForecastingList(Request $req)
    {
        
    session()->put("titlename","Forecasting List - Inventory Planning Admin Panel - Premier Group Of Companies");

    $branchid=session('branchid');
    $branchid2=session('branchid');
    $branchid=explode(',', $branchid);

    $unique_key=$req->unique_key;
    $branch_name=$req->branch_name;
    $branch_name=explode(',', $branch_name);
    $company_name=$req->company_name;
    $for_month=$req->for_month;

    $forecastinglist=DB::table('tbl_forecasting_master')
    ->whereIn('branch_id',$branch_name);
    if($unique_key !="")
    {
      $forecastinglist=$forecastinglist->where([
        ['forcasting_unique_key', '=', $unique_key],
        ]);
    }
    if($company_name !="")
    {
      $forecastinglist=$forecastinglist->where([
        ['company_id', '=', $company_name],
        ]);
    }
    if($for_month !="")
    {
      $forecastinglist=$forecastinglist->where([
        ['forecasting_month', '=', $for_month],
        ]);
    }
    $forecastinglist=$forecastinglist->groupBy('forcasting_unique_key');
    $forecastinglist=$forecastinglist->orderBy('forecasting_id', 'desc');
    $forecastinglist=$forecastinglist->get();
        


  


    $branchdata=DB::SELECT("SELECT * FROM `ipl_branch_master` where branch_code in ($branchid2)");

    $companydata=DB::SELECT("SELECT * FROM `ipl_company_master` order by company_title asc");
   

    return view('forecasting_list',['forecastinglist'=>$forecastinglist,'branchdata'=>$branchdata,'companydata'=>$companydata,'branchid2'=>$branchid2]);
    }


    function ViewForeCasting($fid,$key)
    {
        
    session()->put("titlename","Forecasting View - Inventory Planning Admin Panel - Premier Group Of Companies");

    $branchid=session('branchid');
    $branchid2=session('branchid');
    $branchid=explode(',', $branchid);

    
    $forecastingdetail=DB::SELECT("SELECT fm.*,comp.company_title,br.branch_name,formu.formula_name FROM `tbl_forecasting_master` fm inner join ipl_company_master comp on fm.company_id=comp.company_code inner join ipl_branch_master br on fm.branch_id=br.branch_code inner join ipl_formula_master formu on fm.formula_id=formu.formula_id where fm.forecasting_id=$fid");



    return view('view_forecasting',['forecastingdetail'=>$forecastingdetail,'fid'=>$fid,'key'=>$key]);
    }

    function ExportForeCasting($fid,$Key)
    {
      $forecastingdetail=DB::SELECT("SELECT fm.*,comp.company_title,br.branch_name,formu.formula_name FROM `tbl_forecasting_master` fm inner join ipl_company_master comp on fm.company_id=comp.company_code inner join ipl_branch_master br on fm.branch_id=br.branch_code inner join ipl_formula_master formu on fm.formula_id=formu.formula_id where fm.forecasting_id=$fid");

      return view('export_forecasting',['forecastingdetail'=>$forecastingdetail,'fid'=>$fid,'key'=>$Key]);
    }
    

    



    

    

    













    

}    