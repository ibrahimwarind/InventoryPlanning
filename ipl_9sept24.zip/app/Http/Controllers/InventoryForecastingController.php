<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InventoryForecastingController extends Controller
{
    //
    function CreateInventoryForecasting()
    {
    	session()->put("titlename","Inventory Forecasting - Inventory Planning Admin Panel - Premier Group Of Companies");
    $branchid=session('branchid');
    $branchid2=session('branchid');
    $branchid=explode(',', $branchid);
   
    $formulamasterdata=DB::SELECT("SELECT * FROM `ipl_formula_master`");
    $branchdata=DB::SELECT("SELECT * FROM `ipl_branch_master` order by branch_code asc");

    $companydata=DB::SELECT("SELECT * FROM `ipl_company_master` order by company_title asc");

    return view('create_inventory_forecasting',['formulamasterdata'=>$formulamasterdata,'data'=>'','branchdata'=>$branchdata,'companydata'=>$companydata]);
    }


    function GetFormulaGroup(Request $req)
    {

         $formula_id=$req->formula_id;
        
         $user=DB::select("SELECT * FROM `ipl_group_master` where formula_id='$formula_id'");
         
        return response()->json($user);

        
    }

    function GetGroupCompany(Request $req)
    {

         $group_id=$req->group_id;
         if($group_id !="")
         {
          $user=DB::select("select comp.company_code,comp.company_title from ipl_group_master grp inner join ipl_company_master comp on grp.company_id=comp.company_code where grp.group_id='$group_id'");
         }
         else{
          $user=DB::select("SELECT company_code,company_title FROM `ipl_company_master` order by company_title asc");
         }
         
         
        return response()->json($user);

        
    }
    

    function CreateInventoryForecasting2(Request $req)
    {
      session()->put("titlename","Inventory Forecasting - Inventory Planning Admin Panel - Premier Group Of Companies");
    $branchid=session('branchid');
    $branchid2=session('branchid');
    $branchid=explode(',', $branchid);

    $formula_id=$req->formula_id;
    $formula_det_id=$req->formula_det_id;
    $group_id=$req->group_id;
    $company_id=$req->company_id;
    $branch_id=$req->branch_id;
    $shelf_life=$req->shelf_life;




    $formulamasterdata=DB::SELECT("SELECT * FROM `ipl_formula_master`");
    $branchdata=DB::SELECT("SELECT * FROM `ipl_branch_master` order by branch_code asc");

    $companydata=DB::SELECT("SELECT * FROM `ipl_company_master` order by company_title asc");

    $multiplydata=DB::SELECT("SELECT multiply_by FROM `ipl_formula_detail` where formula_id='$formula_id' AND multiply_by !=2");

    $groupdata=DB::SELECT("select group_id,group_name from ipl_group_master where formula_id='$formula_id'");

    if($group_id !="")
    {
      $productdata=DB::SELECT("SELECT prod.product_code,prod.product_name FROM `ipl_group_mapping` grp inner join ipl_products prod on grp.product_code=prod.product_code where grp.group_id='$group_id' order by prod.product_name asc");
    }
    else{
      $productdata=DB::SELECT("SELECT product_code,product_name FROM `ipl_products` where company_code='$company_id' order by product_name asc");
    }

    return view('create_inventory_forecasting2',['formulamasterdata'=>$formulamasterdata,'data'=>'','branchdata'=>$branchdata,'companydata'=>$companydata,'formula_id'=>$formula_id,'formula_det_id'=>$formula_det_id,'group_id'=>$group_id,'company_id'=>$company_id,'branch_id'=>$branch_id,'shelf_life'=>$shelf_life,'productdata'=>$productdata,'groupdata'=>$groupdata,'multiplydata'=>$multiplydata]);
    }


    function GetCompanyProduct(Request $req)
    {

         $new_company_id=$req->new_company_id;
         
         $user=DB::SELECT("SELECT * FROM `ipl_products` where company_code='$new_company_id'");
         
         
        return response()->json($user);

        
    }

    function GetFormulaMultiply(Request $req)
    {

         $formula_id=$req->formula_id;
         
         $user=DB::SELECT("SELECT multiply_by FROM `ipl_formula_detail` where formula_id='$formula_id'");
         
         
        return response()->json($user);

        
    }

    function GetProductInventoryCosting(Request $req)
    {

         $new_product_id=$req->new_product_id;
         $branch_id=$req->branch_id;

         $productname="";
         $productdata=DB::SELECT("SELECT * FROM `ipl_products` where product_code='$new_product_id'");
         foreach($productdata as $prd)
         {
          $productname=$prd->product_name;
         }

         $sales_qty1=0;$month_year1="";$sales_qty2=0;$month_year2="";$sales_qty3=0;$month_year3="";$in_stock=0;$in_stock_monthyear="";$in_transitstock=0;

         $invdata=DB::SELECT("SELECT sales_qty1,month_year1,sales_qty2,month_year2,sales_qty3,month_year3,in_stock,in_stock_monthyear,in_transitstock FROM `ipl_branchwise_product_stock` where branch_code=$branch_id AND product_code=$new_product_id");
         foreach($invdata as $inv)
         {
          $sales_qty1=$inv->sales_qty1;
          $sales_qty2=$inv->sales_qty2;
          $sales_qty3=$inv->sales_qty3;
          $in_stock=$inv->in_stock;
          $in_transitstock=$inv->in_transitstock;


         }

         
         $responseData = [
        'product_name' => $productname,
        'sales_qty1' => $sales_qty1,
        'sales_qty2' => $sales_qty2,
        'sales_qty3' => $sales_qty3,
        'in_stock' => $in_stock,
        'in_transitstock' => $in_transitstock,
       ];
         
        return response()->json($responseData);
        
    }


    function SaveForecasting(Request $req)
    {
    
    session()->put("titlename","Inventory Forecasting - Inventory Planning Admin Panel - Premier Group Of Companies");
    $branchid=session('branchid');
    $branchid2=session('branchid');
    $branchid=explode(',', $branchid);

    $formula_id=$req->formula_id;
    $formula_det_id=$req->formula_det_id;
    $group_id=$req->group_id;
    $company_id=$req->company_id;
    $branch_id=$req->branch_id;
    $shelf_life=$req->shelf_life;
    $multiply_by=$req->multiply_by;
    $formulaname=$req->formulaname;
    $indexcount=$req->indexcount;
    $formno=0;
    $data_formno=DB::SELECT("SELECT COALESCE(MAX(forcasting_formno), 0) + 1 AS newforcasting FROM tbl_forecasting_master");
    foreach($data_formno as $fmno)
    {
      $formno=$fmno->newforcasting;
    }

    $unique_key="FCST_".date('Ymd')."0".$formno;
    $version_no=1;
    $myuserid=session("adminname");
    date_default_timezone_set("Asia/Karachi");
    $currentdate=date('Y-m-d h:i:s');



    DB::table('tbl_forecasting_master')
          ->insert([
            'forcasting_unique_key' => $unique_key,
            'forcasting_formno' => $formno,
            'version_no'=>$version_no,
            'formula_id'=>$formula_id,
            'formula_detail_id'=>$formula_det_id,
            'group_id'=>$group_id,
            'company_id'=>$company_id,
            'branch_id'=>$branch_id,
            'shelf_life'=>$shelf_life,
            'multiply_by'=>$multiply_by,
            'post_user'=>$myuserid,
            'post_datetime'=>$currentdate,
          ]);

   $forecasting_id=0;
    $dbdataforcast=DB::SELECT("SELECT forecasting_id FROM `tbl_forecasting_master` order by forecasting_id desc limit 1");
    foreach($dbdataforcast as $fcr)
    {
     $forecasting_id=$fcr->forecasting_id;
    }

    for($i=1;$i <= $indexcount;$i++)
    {
      $productcode=$req->input('productcode'.$i);
      $saleqty1_=$req->input('saleqty1_'.$i);
      $saleqty2_=$req->input('saleqty2_'.$i);
      $saleqty3_=$req->input('saleqty3_'.$i);
      $salemonth_1_=$req->input('salemonth_1_'.$i);
      $salemonth_2_=$req->input('salemonth_2_'.$i);
      $salemonth_3_=$req->input('salemonth_3_'.$i);
      $avgsales=$req->input('avgsales'.$i);
      $maxsales=$req->input('maxsales'.$i);
      $instock=$req->input('instock'.$i);
      $in_transitstock=$req->input('in_transitstock'.$i);
      $netstock=$req->input('netstock'.$i);
      $formulaoutput=$req->input('formulaoutput'.$i);
      $demand=$req->input('demand'.$i);
      $finaloutput=$req->input('finaloutput'.$i);
      $rowformulaid=$req->input('rowformulaid'.$i);
      $new_multiply_by=$req->input('new_multiply_by'.$i);
      $instockmonth=$req->input('instockmonth'.$i);

      DB::table('ipl_forecasting_detail')
          ->insert([
            'forecasting_id' => $forecasting_id,
            'product_code' => $productcode,
            'sale_qty1'=>$saleqty1_,
            'sale_qty2'=>$saleqty2_,
            'sale_qty3'=>$saleqty3_,
            'sale_month1'=>$salemonth_1_,
            'sale_month2'=>$salemonth_2_,
            'sale_month3'=>$salemonth_3_,
            'avg_sales'=>$avgsales,
            'max_sales'=>$maxsales,
            'current_stock'=>$instock,
            'current_stockmonth'=>$instockmonth,
            'in_transit_stock'=>$in_transitstock,
            'net_stock'=>$netstock,
            'pr_diff'=>$formulaoutput,
            'demand'=>$demand,
            'pspl_diff'=>$finaloutput,
            'formula_id'=>$rowformulaid,
            'formula_detail_id'=>$formula_det_id,
            'multiply_by'=>$new_multiply_by,
          ]);

      

    }

   
    return view('create_inventory_forecasting3',['forecasting_id'=>$forecasting_id]);
    }


    

    

    













    

}    