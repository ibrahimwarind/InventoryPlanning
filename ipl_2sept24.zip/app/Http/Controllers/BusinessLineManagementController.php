<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BusinessLineManagementController extends Controller
{
    //
    function AddMinBookingAmount()
    {
    	session()->put("titlename","Min Booking Amount Management - Sales Booster Admin Panel - Premier Group Of Companies");
    $branchid=session('branchid');
    $branchid2=session('branchid');
    $branchid=explode(',', $branchid);
    $admintype=session('admintype');
    $usercode=session('usercode');

    $groupdata=DB::SELECT("SELECT supply_groupid,supply_groupname FROM `sb_business_line` where branch_code ='$branchid2' AND supply_groupid not in (SELECT supply_groupid FROM `sb_businessline_restriction` where branch_code='$branchid2') group by supply_groupid");

    $restricteddata=DB::SELECT("SELECT * FROM `sb_businessline_restriction` where branch_code='$branchid2'");


    return view('add_min_booking_amount',['groupdata'=>$groupdata,'restricteddata'=>$restricteddata,'data'=>'']);


    }

    function AddMinBookingAmount2(Request $req)
    {

    	$bus_line=$req->input("bus_line");
    	$min_booking_amount=$req->input("min_booking_amount");
    	$max_booking_amount=$req->input("max_booking_amount");
        $branchid2=session('branchid');

       
        if($bus_line == 0)
        {
            DB::table('sb_businessline_restriction')
            ->where([
            ['branch_code','=',$branchid2],
            ])
            ->delete();
            
           $getbusinliness=DB::SELECT("SELECT supply_groupid,supply_groupname FROM `sb_business_line` where branch_code ='$branchid2' AND supply_groupid not in (SELECT supply_groupid FROM `sb_businessline_restriction` where branch_code='$branchid2') group by supply_groupid");
           foreach($getbusinliness as $supid)
           {
               $supply_groupid=$supid->supply_groupid;

               $groupname="";
               $getgrname=DB::SELECT("select supply_groupname from sb_business_line where branch_code='$branchid2' AND supply_groupid='$supply_groupid'");
               foreach($getgrname as $get)
               {
                   $groupname=$get->supply_groupname;
               }

               date_default_timezone_set("Asia/Karachi");
               $date = date('Y-m-d H:i:s');
       
               DB::table('sb_businessline_restriction')
               ->insert([
                   'branch_code' => $branchid2,
                   'supply_groupid' => $supply_groupid,
                   'supply_groupname'=>$groupname,
                   'min_booking_amount'=>$min_booking_amount,
                   'max_booking_amount'=>$max_booking_amount,
               ]);

               DB::table('sb_change_maxbooking_log')
               ->insert([
                   'branch_code' => $branchid2,
                   'group_id' => $supply_groupid,
                   'min_bookingamount'=>$min_booking_amount,
                   'log_datetime'=>$date,
               ]);

               

           }

           $groupdata=DB::SELECT("SELECT supply_groupid,supply_groupname FROM `sb_business_line` where branch_code ='$branchid2' AND supply_groupid not in (SELECT supply_groupid FROM `sb_businessline_restriction` where branch_code=143) group by supply_groupid");

           $restricteddata=DB::SELECT("SELECT * FROM `sb_businessline_restriction` where branch_code='$branchid2'");
       
           
           return view('add_min_booking_amount',['data'=>'Max Booking has been successfully set','groupdata'=>$groupdata,'restricteddata'=>$restricteddata]);
   

        }
        else{

            $groupname="";
            $getgrname=DB::SELECT("select supply_groupname from sb_business_line where branch_code='$branchid2' AND supply_groupid='$bus_line'");
            foreach($getgrname as $get)
            {
                $groupname=$get->supply_groupname;
            }

    	$count=DB::table('sb_businessline_restriction')
        ->where([
        ['branch_code','=',$branchid2],
        ['supply_groupid','=',$bus_line],
        ])
        ->count();
    
        // return view('index',['data'=>$count]);
        if($count == 0)
        {
        
        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d H:i:s');

        DB::table('sb_businessline_restriction')
        ->insert([
            'branch_code' => $branchid2,
            'supply_groupid' => $bus_line,
            'supply_groupname'=>$groupname,
            'min_booking_amount'=>$min_booking_amount,
            'max_booking_amount'=>$max_booking_amount,
        ]);

        DB::table('sb_change_maxbooking_log')
        ->insert([
            'branch_code' => $branchid2,
            'group_id' => $bus_line,
            'min_bookingamount'=>$min_booking_amount,
            'log_datetime'=>$date,
        ]);
        
        $groupdata=DB::SELECT("SELECT supply_groupid,supply_groupname FROM `sb_business_line` where branch_code ='$branchid2' AND supply_groupid not in (SELECT supply_groupid FROM `sb_businessline_restriction` where branch_code=143) group by supply_groupid");

        $restricteddata=DB::SELECT("SELECT * FROM `sb_businessline_restriction` where branch_code='$branchid2'");
    
    	
        return view('add_min_booking_amount',['data'=>'Max Booking has been successfully set','groupdata'=>$groupdata,'restricteddata'=>$restricteddata]);

        }
        else
        {
        
            $groupdata=DB::SELECT("SELECT supply_groupid,supply_groupname FROM `sb_business_line` where branch_code ='$branchid2' AND supply_groupid not in (SELECT supply_groupid FROM `sb_businessline_restriction` where branch_code='$branchid2') group by supply_groupid");

            $restricteddata=DB::SELECT("SELECT * FROM `sb_businessline_restriction` where branch_code='$branchid2'");
        
            
        	return view('add_min_booking_amount',['data'=>'Max Booking Already Exist','groupdata'=>$groupdata,'restricteddata'=>$restricteddata]);

        }

    }

    

    }

    function DeleteRestriction($id,$sname)
    {
        $branchid2=session('branchid');
       DB::table('sb_businessline_restriction')
        ->where('restric_id', $id)
        ->delete();

        $data="Group ".$sname." successfully Deleted";

    	    $groupdata=DB::SELECT("SELECT supply_groupid,supply_groupname FROM `sb_business_line` where branch_code ='$branchid2' AND supply_groupid not in (SELECT supply_groupid FROM `sb_businessline_restriction` where branch_code=143) group by supply_groupid");

            $restricteddata=DB::SELECT("SELECT * FROM `sb_businessline_restriction` where branch_code='$branchid2'");
        
            
        	return view('add_min_booking_amount',['data'=>$data,'groupdata'=>$groupdata,'restricteddata'=>$restricteddata]);

    }


}    